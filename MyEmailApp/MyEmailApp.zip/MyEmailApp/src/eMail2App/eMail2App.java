package eMail2App;

public class eMail2App {

        public static void main(String[] args){
        eMail2 em1 = new eMail2 ("John", "Smith");

//        em1.setAlternateEmail("js@live.com");
//            System.out.println(em1.getAlternateEmail());
            System.out.println(em1.showInfo());

    }

}

